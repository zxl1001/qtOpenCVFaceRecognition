#include "test_precomp.hpp"

CV_TEST_MAIN(".", /*Empty VA_ARGS for C++11*/)
